function time(){
     var date = new Date();
     var year = date.getFullYear();
     var month = date.getMonth()+1;
     var day = date.getDate()
    var hour =date.getHours();
     hour=hour<10?"0"+hour:hour;
    var minute =date.getMinutes();
     minute=minute<10?"0"+minute:minute;
     var second = date.getSeconds();
     second=second<10?"0"+second:second;
    var daysInMonth = [0,31,28,31,30,31,30,31,31,30,31,30,31];
    //昨天时间
    var zhh=" 16:41";
    
    
     var currentTime = year+"-"+month+"-"+day+"  "+hour+":"+minute+":"+second;
    
     document.getElementById("time").innerHTML=year+"-"+month+"-"+(day-1)+zhh;      
    document.getElementById("timeh").innerHTML=hour+":"+minute;
    document.getElementById("timey").innerHTML=year+"-"+month+"-"+day;
    document.getElementById("ytimey").innerHTML=year+"-"+month+"-"+day;
    document.getElementById("timess").innerHTML=second;
    
    
    if(day<=9){
        document.getElementById("time").innerHTML=year+"-"+month+"-0"+(day-1)+zhh;     
        if(day==1){
        document.getElementById("time").innerHTML=year+"-"+(month-1)+"-"+daysInMonth[month-1]+zhh;     
        }
        document.getElementById("timeh").innerHTML=hour+':'+minute;
        document.getElementById("timey").innerHTML=year+"-"+month+"-0"+day;
        document.getElementById("ytimey").innerHTML=year+"-"+month+"-0"+day;
        document.getElementById("timess").innerHTML=second;
    }
    if(day==10){
        document.getElementById("time").innerHTML=year+"-"+month+"-0"+(day-1)+zhh;
        }
 }
setInterval("time()",1000);
