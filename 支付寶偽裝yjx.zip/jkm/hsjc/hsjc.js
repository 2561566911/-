function time(){
     var date = new Date();
     var year = date.getFullYear();
     var month = date.getMonth();
     var day = date.getDate();
    var hour =date.getHours();
     hour=hour<10?"0"+hour:hour;
    var minute =date.getMinutes();
     minute=minute<10?"0"+minute:minute;
     var second = date.getSeconds();
     second=second<10?"0"+second:second;
    
    //1
    var daysInMonth = [0,31,28,31,30,31,30,31,31,30,31,30,31];
    var day1=day-1;
    var day2=day-2;
    var day3=day-3;
    var day4=day-4;
    var month1=month+1;
    
    if(day==1)
    {
        day1=daysInMonth[month];         //31
        day2=daysInMonth[month]-1;      //30
        day3=daysInMonth[month]-2;      //29
        day4=daysInMonth[month]-3;      //28
    }
    if(day==2)
    {
        //11 10 10 10
        day1="0"+1;                             //1
        day2=daysInMonth[month];        //31
        day3=daysInMonth[month]-1;      //30
        day4=daysInMonth[month]-2;      //29
    }
    if(day==3)
    {
        //11 11 10 10
        day1="0"+2;//2
        day2="0"+1;//1
        day3=daysInMonth[month];//31
        day4=daysInMonth[month]-1;//30
    }
    //1234 56789
    if(day==4)
    {
        //11 11 11 10
        day1="0"+3;//3
        day2="0"+2;//2
        day3="0"+1;//1
        day4=daysInMonth[month];//31
    }
    if(day==5)
    {
        day1="0"+4;//4
        day2="0"+3;//3
        day3="0"+2;//2
        day4="0"+1;//1
    }
    if(day==6)
    {
        day1="0"+5;//5
        day2="0"+4;//4
        day3="0"+3;//3
        day4="0"+2;//2
    }
    if(day==7)
    {
        day1="0"+6;//6
        day2="0"+5;//5
        day3="0"+4;//4
        day4="0"+3;//3
    }
    if(day==8)
    {
        day1="0"+7;//7
        day2="0"+6;//6
        day3="0"+5;//5
        day4="0"+4;//4
    }
    if(day==9)
    {
        day1="0"+8;//8
        day2="0"+7;//7
        day3="0"+6;//6
        day4="0"+5;//5
    }
    document.getElementById("timey1").innerHTML=year+"-"+month+"-"+day1;
    document.getElementById("timey5").innerHTML=year+"-"+month+"-"+day1;
    
    document.getElementById("timey2").innerHTML=year+"-"+month+"-"+day2;
    document.getElementById("timey3").innerHTML=year+"-"+month+"-"+day3;
    document.getElementById("timey4").innerHTML=year+"-"+month+"-"+day4;
    
    
    if(day==2)
    {
        //11 10 10 10
        document.getElementById("timey1").innerHTML=year+"-"+month1+"-"+day1;
    document.getElementById("timey5").innerHTML=year+"-"+month1+"-"+day1;
    
    document.getElementById("timey2").innerHTML=year+"-"+month+"-"+day2;
    document.getElementById("timey3").innerHTML=year+"-"+month+"-"+day3;
    document.getElementById("timey4").innerHTML=year+"-"+month+"-"+day4;
    }
    if(day==3)
    {
        //11 11 10 10
        document.getElementById("timey1").innerHTML=year+"-"+month1+"-"+day1;
    document.getElementById("timey5").innerHTML=year+"-"+month1+"-"+day1;
    
    document.getElementById("timey2").innerHTML=year+"-"+month1+"-"+day2;
    document.getElementById("timey3").innerHTML=year+"-"+month+"-"+day3;
    document.getElementById("timey4").innerHTML=year+"-"+month+"-"+day4;
    }
    if(day==4)
    {
        //11 11 11 10
        document.getElementById("timey1").innerHTML=year+"-"+month1+"-"+day1;
    document.getElementById("timey5").innerHTML=year+"-"+month1+"-"+day1;
    
    document.getElementById("timey2").innerHTML=year+"-"+month1+"-"+day2;
    document.getElementById("timey3").innerHTML=year+"-"+month1+"-"+day3;
    document.getElementById("timey4").innerHTML=year+"-"+month+"-"+day4;
    }
}
function js_sx(){
document.getElementById("sx_ck").style="display: block;";
document.getElementById("sx_h").style="display: block;";
document.getElementById("bodyy").style="overflow-y: hidden;";
}

function js_qx(){
document.getElementById("sx_ck").style="display:none;";
document.getElementById("sx_h").style="display:none;";
document.getElementById("bodyy").style="overflow-y: visible;";
}
//setInterval("time()",1000);