function time(){
     var date = new Date();
     var year = date.getFullYear();
     var month = date.getMonth()+1;
     var day = date.getDate()
    var hour =date.getHours();
     hour=hour<10?"0"+hour:hour;
    var minute =date.getMinutes();
     minute=minute<10?"0"+minute:minute;
     var second = date.getSeconds();
     second=second<10?"0"+second:second;
    
     var currentTime = year+"."+month+"."+day+" "+hour+":"+minute+":"+second;
    
     document.getElementById("timeS").innerHTML=currentTime;
    tp();
}
//tp放大
//scale---
var x=1;
var y=0;
function tp(){
    if(y<50){
        //var a="width:"+(100+x)+"%;"+"height:"+(100+x)+"%;";
        //alert(x);
        document.getElementById("jtimg").style.cssText = "transform:scale("+x+","+x+");";
        x+=0.005;
    }
    if((y<100)&&(y>=50))
    {
        x-=0.005;
        //var a="width:"+(125-x)+"%;"+"height:"+(100-x)+"%;";
        //alert(x);
        document.getElementById("jtimg").style.cssText = "transform:scale("+x+","+x+");";
    }
    y++;
    if(y==100)
    {y=0;x=1;}
}
setInterval("tp()",10);